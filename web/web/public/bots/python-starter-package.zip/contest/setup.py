from distutils.core import setup

setup(
    name='pacman',
    version='0.0.1',
    description='',
    author='UC Berkeley & JDIS',
    author_email='ismael.balafrej@usherbrooke.ca',
    url='http://www.gel.usherbrooke.ca/necotis/',
    packages=['pacman'],
    install_requires=[],
    python_requires=">=3.6.6"
)
